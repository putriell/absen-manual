package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText tanggal, waktu, keterangan;
    Button submit;
    Spinner spinner;
    ArrayAdapter <CharSequence> adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // inisiasi id
        tanggal = findViewById(R.id.tanggal);
        waktu = findViewById(R.id.waktu);
        keterangan = findViewById(R.id.keterangan);
        spinner = findViewById(R.id.spinner);

        //spinner di xml
        if(spinner != null) {
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                }

                @Override
                public void onNothingSelected(AdapterView<?> adapterView) {

                }
            });
        }
        //label yang ditampilkan di spinner
        adapter = ArrayAdapter.createFromResource(this, R.array.status, android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);

        if(spinner != null) {
            spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        }

        //menampilkan alert dialog
        submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showAlertDialog();
            }
        });

        tanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });

        waktu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePicker();
            }
        });
    }

    public void showDatePicker(){
        DialogFragment dateFragment = new DatePickerFragment();
        dateFragment.show(getSupportFragmentManager(), "date-picker");
    }

    public void showTimePicker(){
        DialogFragment dateFragment = new TimePickerFragment();
        dateFragment.show(getSupportFragmentManager(), "time-picker");
    }

    public void showAlertDialog(){
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(MainActivity.this);
        alertBuilder.setTitle("konfirmasi");
        alertBuilder.setMessage("Apakah anda yakin jika data yang anda kirim sudah sesuai?");

        alertBuilder.setPositiveButton("ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Toast.makeText(getApplicationContext(), "absen berhasil", Toast.LENGTH_SHORT).show();
                tanggal.setText("");
                waktu.setText("");
                keterangan.setText("");
                spinner.setAdapter(adapter);
            }
        });
        alertBuilder.setNegativeButton("tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                tanggal.setText("");
                waktu.setText("");
                keterangan.setText("");
                spinner.setAdapter(adapter);
            }
        });
        //menampilkan function alertBuilder
        alertBuilder.show();
    }

    //menampilkan tanggal
    public void processDatePickerResult(int day, int month, int year) {
        String day_string = Integer.toString(day);
        String moth_string = Integer.toString(month+1);
        String year_string = Integer.toString(year);

        String dateMessage = day_string + "-" + moth_string + "-" + year_string;
        tanggal.setText(dateMessage);
    }

    //menampilkan waktu
    public void processTimePickerResult(int hour, int minute) {
        String hour_string = Integer.toString(hour);
        String minute_string = Integer.toString(minute);

        String timeMessage = hour_string + ":" + minute_string;
        waktu.setText(timeMessage);
    }

    //spinner di klik
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        if (spinner.getSelectedItem().toString().equals("hadir tepat waktu")) {
            keterangan.setVisibility(view.INVISIBLE);
        }
        else {
            keterangan.setVisibility(view.VISIBLE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}